from django.contrib import admin
from App_main.models import *

# Register your models here.
admin.site.register(CategoryModel)
admin.site.register(MedicineGenericModel)
admin.site.register(CompanyModel)
admin.site.register(ConsumingType)
admin.site.register(MedicineModel)
admin.site.register(CartModel)
admin.site.register(Order)
