from django.contrib import admin
from App_auth.models import *

# Register your models here.
admin.site.register(ProfileModel)
admin.site.register(CityModel)
admin.site.register(AreaModel)
admin.site.register(DeliveryAddressModel)
